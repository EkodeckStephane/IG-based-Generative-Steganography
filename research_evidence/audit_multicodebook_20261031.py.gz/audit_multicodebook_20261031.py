"""Independent structural, arithmetic and codebook-seed audit.
Does not re-execute sampling or replace a numerical rerun.
"""
from pathlib import Path
import json, csv, itertools, hashlib
import numpy as np
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'multicodebook_results.json').read_text())
assert r['checkpoint_sha256']=='e94d57b36d960921768ce8ccc889796d5cd4ce69ce794a90ed1b669ed1d1ed61'
assert r['positive_control']['pixel']>=.8 and r['positive_control']['latent_geometry']>=.8
bs=r['protocol']['codebook_definition'];d=r['details']
assert len(bs)==4 and len(d)==4
methods=['Algorithm 2: MC Fisher','Natural gradient: exact Fisher','Euclidean gradient descent','iMEC: common Bernoulli channel','Discop: common Bernoulli channel']
allbooks=[]
for info in bs:
 name=info['name'];rng=np.random.default_rng(info['draw_seed'])
 a=rng.uniform(0,2*np.pi)+np.arange(4)*np.pi/2+rng.uniform(-.24,.24,4)
 radii=rng.uniform(.75,1.25,size=4);book=np.column_stack([radii*np.cos(a),radii*np.sin(a)])
 assert np.allclose(book,d[name]['book']);assert np.all(np.linalg.norm(book,axis=1)>.7)
 assert min(np.linalg.norm(book[i]-book[j]) for i in range(4) for j in range(i+1,4))>.2
 allbooks.append(book)
 for method in methods:
  z=d[name]['methods'][method];assert 0<=z['decode_exact_ml_or_native']<=80
  assert z['test_n']==80
  if z['decode_exact_public_encoder'] is not None:assert 0<=z['decode_exact_public_encoder']<=80
  if z['converged_targets'] is not None:assert 0<=z['converged_targets']<=4
for a,b in itertools.combinations(allbooks,2):assert not np.allclose(a,b)
recs=r['detectors'];assert len(recs)==80
unique=set()
for row in recs:
 key=row['method'],row['heldout_codebook'],row['detector'];assert key not in unique;unique.add(key)
 assert row['train_n']==480 and row['test_n']==160
 assert 0<=row['CI95_lo']<=row['AUC']<=row['CI95_hi']<=1
assert len(unique)==len(recs)
for fn,count in [('multicodebook_decode.csv',20),('multicodebook_detectors.csv',80)]:
 with (ROOT/fn).open() as f:assert len(list(csv.DictReader(f)))==count
print('PASS: 4 independently-seeded predeclared codebooks; no cover codeword; 5 algorithms x 4 books; 80 LOCO AUC records; ML versus public-encoder decode separated; positive controls; all CIs, protocol sizes and CSV rows consistent.')
for p in sorted(ROOT.glob('multicodebook*')):
 if p.is_file():print(p.name,hashlib.sha256(p.read_bytes()).hexdigest())
