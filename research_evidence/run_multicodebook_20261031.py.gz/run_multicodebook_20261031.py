"""R2.7/R2.3 exploratory multi-codebook evaluation, no cover-valued message codeword.

Produces per-codebook message decode and leave-one-codebook-out (LOCO) adversarial
results. This controlled Bernoulli channel IS NOT the native full iMEC/Discop
pipeline nor the original class-means S5. No general security claim.

Requires a local submission source checkout with benchmark_s5_comparison.py, its
pinned upstream iMEC adapter, and data/s5_vae_mnist.pt.
"""
from __future__ import annotations
import argparse,hashlib,csv,json,sys,time,os
from pathlib import Path
import numpy as np, torch
from scipy.special import logsumexp
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import roc_auc_score

HERE=Path(__file__).resolve().parent
ROOT=Path(os.environ.get('DSP_PROJECT_ROOT', str(HERE.parents[2] if HERE.parent.name=='research_evidence' and HERE.parent.parent.name=='Version_1.0' else HERE.parent))).resolve()
if not (ROOT/'Version_1.0'/'benchmark_s5_comparison.py').exists():
    raise FileNotFoundError('Set DSP_PROJECT_ROOT to the extracted submission bundle root that contains Version_1.0/benchmark_s5_comparison.py')
SRC=ROOT/'Version_1.0'
sys.path.insert(0,str(SRC));sys.path.insert(0,str(SRC/'research_evidence'))
import benchmark_s5_comparison as b
from r27_algorithm2_direct_v1 import optimization,model_info,pub_features

METHODS=('Algorithm 2: MC Fisher','Natural gradient: exact Fisher','Euclidean gradient descent','iMEC: common Bernoulli channel','Discop: common Bernoulli channel')
SEED=20261031
CODEBOOKS=[{'name':f'R{j+1}','draw_seed':s} for j,s in enumerate((5101,5203,5309,5413))]
Z0=np.array([0.,0.])

def make_book(draw_seed):
    rng=np.random.default_rng(draw_seed)
    a=rng.uniform(0,2*np.pi)+np.arange(4)*np.pi/2+rng.uniform(-.24,.24,4)
    radii=rng.uniform(.75,1.25,size=4)
    return np.column_stack([radii*np.cos(a),radii*np.sin(a)])

def balanced_payloads(n,seed):
    assert n%4==0
    return np.random.default_rng(seed).permutation(np.tile(np.arange(4),n//4))

def public_feat(model,xx,F):
    feat=pub_features(model,xx,F,Z0)
    # Normalized image-energy and overall brightness give public image observables
    return np.column_stack([feat,np.mean(xx,axis=1),np.std(xx,axis=1)])

def loglik_decode(imgs,ps):
    imgs=imgs.astype(float)
    ps=np.clip(ps,1e-7,1-1e-7)
    loglik=imgs@np.log(ps).T+(1-imgs)@np.log1p(-ps).T
    return np.argmax(loglik,axis=1)

def run(train_n=80,test_n=80,MC=128,steps=65,bootstrap=200,skip_imec=False):
    torch.set_num_threads(1)
    model=b.load_model();p0=b.decoder_probs(model,Z0);F=b.fisher_metric(model,Z0)
    checkpoint=ROOT/'data'/'s5_vae_mnist.pt'
    fingerprint=hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    assert checkpoint.is_file()
    records=[]; details={}; data={}
    for j,info in enumerate(CODEBOOKS):
        name=info['name'];book=make_book(info['draw_seed'])
        assert (np.linalg.norm(book-Z0[None,:],axis=1)>0.7).all()
        assert np.min(np.linalg.norm(book[:,None,:]-book[None,:,:]+np.eye(4)[:,:,None]*1e5,axis=2))>.2
        details[name]={'book':book.tolist(),'min_distance_from_cover':float(np.min(np.linalg.norm(book,axis=1))),'solutions':{},'methods':{}}
        covers={};messages={}
        for split,n,offset in [('train',train_n,0),('test',test_n,1000000)]:
            covers[split]=np.stack([b.sample_cover(p0,SEED+j*100000+offset+i) for i in range(n)]).astype(np.uint8)
            messages[split]=balanced_payloads(n,SEED+j*100000+offset+932)
        for k,method in enumerate(METHODS):
            if skip_imec and method.startswith('iMEC'):continue
            sol=[]
            if k<3:
                for v,target in enumerate(book):
                    sol.append(optimization(model,Z0,target,method,np.random.default_rng(SEED+j*10000+100*k+v),N=MC,max_iter=steps))
                details[name]['solutions'][method]=sol
            distributions=np.stack([b.decoder_probs(model,np.asarray(x['z'])) for x in sol]) if sol else None
            datasets={};times=[]
            for split,n,offset in [('train',train_n,0),('test',test_n,1000000)]:
                msgs=messages[split];stego=[];decoded=[]
                for i,m in enumerate(msgs):
                    sample_seed=SEED+j*100000+offset+200000+i
                    if k<3:
                        ste=b.sample_cover(distributions[int(m)],sample_seed)
                        # ML codebook receiver on known output distributions
                        dec=None
                    elif k==3:
                        msgbits=b.int_to_bits(int(m),2)
                        ste,dbits,enc,dec_t,_=b.imec_encode_decode(p0,msgbits,sample_seed,None)
                        dec=b.bits_to_int(dbits);times.append([enc,dec_t])
                    else:
                        msgbits=b.int_to_bits(int(m),2)
                        ste,dbits,enc,dec_t,_=b.discop_encode_decode(p0,msgbits,sample_seed)
                        dec=b.bits_to_int(dbits);times.append([enc,dec_t])
                    stego.append(np.asarray(ste,dtype=np.uint8))
                    if dec is not None:decoded.append(dec)
                stego=np.stack(stego)
                if k<3:
                    decoded=loglik_decode(stego,distributions).tolist()
                    with torch.no_grad():zmean,_=model.encode(torch.as_tensor(stego,dtype=torch.float32))
                    encoder_decoded=np.argmin(np.sum((zmean.numpy()[:,None,:]-book[None,:,:])**2,axis=2),axis=1)
                else:encoder_decoded=None
                datasets[split]={'cover':covers[split],'stego':stego,'true_messages':msgs,'decoded':np.asarray(decoded),'encoder_decoded':encoder_decoded}
            p=datasets['test']
            dx=int(np.sum(p['decoded']==p['true_messages']))
            e_dec=int(np.sum(p['encoder_decoded']==p['true_messages'])) if p['encoder_decoded'] is not None else None
            mean_mse=float(np.square(p['stego'].astype(float)-p0).mean())
            details[name]['methods'][method]={'decode_exact_ml_or_native':dx,'decode_exact_public_encoder':e_dec,'test_n':test_n,'mse':mean_mse,'converged_targets':sum(x['converged'] for x in sol) if sol else None,'encode_ms_median':float(np.median(np.asarray(times)[:,0])*1e3) if times else None}
            data[(name,method)]=datasets
            print('DONE',name,method,'decode',dx,'encoder',e_dec,'converged',sum(x['converged'] for x in sol) if sol else 'NA',flush=True)
            (HERE/'partial_per_codebook.json').write_text(json.dumps({'details':details,'checkpoint':fingerprint},indent=2))
    # LOCO cross-codebook: train detector on two independently generated books;
    # test on held-out third. No test labels enter model fitting.
    for method in METHODS:
        if skip_imec and method.startswith('iMEC'):continue
        for held in [x['name'] for x in CODEBOOKS]:
            tnames=[x['name'] for x in CODEBOOKS if x['name']!=held]
            train=np.concatenate([np.vstack([data[(c,method)]['train']['cover'],data[(c,method)]['train']['stego']]) for c in tnames])
            yy=np.concatenate([np.r_[np.zeros(train_n),np.ones(train_n)] for _ in tnames])
            test=np.vstack([data[(held,method)]['test']['cover'],data[(held,method)]['test']['stego']]);yt=np.r_[np.zeros(test_n),np.ones(test_n)]
            ft=public_feat(model,train,F);fq=public_feat(model,test,F)
            choices=[('pixel_logistic',train,test,make_pipeline(StandardScaler(),LogisticRegression(max_iter=1200,C=.5,random_state=SEED))),
                     ('pixel_RBF_SVM',train,test,make_pipeline(StandardScaler(),SVC(C=2,kernel='rbf',gamma='scale'))),
                     ('latent_geometry_RBF_SVM',ft,fq,make_pipeline(StandardScaler(),SVC(C=2,kernel='rbf',gamma='scale'))),
                     ('fusion_RBF_SVM',np.column_stack([train,ft]),np.column_stack([test,fq]),make_pipeline(StandardScaler(),SVC(C=2,kernel='rbf',gamma='scale')))]
            for n,(label,xtr,xte,model_det) in enumerate(choices):
                model_det.fit(xtr,yy)
                scores=model_det.decision_function(xte) if hasattr(model_det,'decision_function') else model_det.predict_proba(xte)[:,1]
                auc=float(roc_auc_score(yt,scores))
                pos=np.flatnonzero(yt==1);neg=np.flatnonzero(yt==0);rng=np.random.default_rng(SEED+17*n+500*CODEBOOKS.index(next(x for x in CODEBOOKS if x['name']==held)))
                boot=[]
                for _ in range(bootstrap):
                    indices=np.r_[rng.choice(pos,len(pos)),rng.choice(neg,len(neg))]
                    boot.append(float(roc_auc_score(yt[indices],scores[indices])))
                lo,hi=np.quantile(boot,[.025,.975])
                records.append({'method':method,'heldout_codebook':held,'detector':label,'AUC':auc,'CI95_lo':lo,'CI95_hi':hi,'train_n':int(len(yy)),'test_n':int(len(yt))})
            print('TEST',method,held,{r['detector']:round(r['AUC'],4) for r in records if r['method']==method and r['heldout_codebook']==held},flush=True)
    # positive control distinct from codebook evaluation. Same task and split.
    def pc(n,offset):
        xa=np.stack([b.sample_cover(p0,SEED+offset+i) for i in range(n)]).astype(np.uint8)
        pb=b.decoder_probs(model,np.array([2.2,1.8]));xb=np.stack([b.sample_cover(pb,SEED+offset+10000+i) for i in range(n)]).astype(np.uint8)
        return np.vstack([xa,xb]),np.r_[np.zeros(n),np.ones(n)]
    a,ya=pc(train_n*2,20000000);q,yq=pc(test_n,30000000)
    positive={}
    for name,trainfeat,testfeat in [('pixel',a,q),('latent_geometry',public_feat(model,a,F),public_feat(model,q,F))]:
        clf=make_pipeline(StandardScaler(),SVC(C=2,kernel='rbf',gamma='scale')).fit(trainfeat,ya)
        positive[name]=float(roc_auc_score(yq,clf.decision_function(testfeat)))
    output={'protocol':{'seed':SEED,'train_per_class_per_book':train_n,'test_per_class_per_book':test_n,'codebook_definition':CODEBOOKS,'MC_Fisher_samples':MC,'optimizer_max_iter':steps,'optimizer_kl_tol':1e-5,'bootstrap_replicates':bootstrap,'scope':'Exploratory multi-codebook Bernoulli-VAE controlled channel, synthetic endpoints, not original class-means MNIST and not full native iMEC/Discop pipelines','warnings':['Adaptive retraining is detector-only, not embedder minimax adversarial training','ML receiver assumes known per-message generated distribution; public encoder receiver is separately reported','Three fixed codebooks offer weak generality; held-out codebook is disjoint but shared model']},'checkpoint_sha256':fingerprint,'details':details,'detectors':records,'positive_control':positive}
    (HERE/'multicodebook_results.json').write_text(json.dumps(output,indent=2))
    with (HERE/'multicodebook_detectors.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=records[0].keys());w.writeheader();w.writerows(records)
    with (HERE/'multicodebook_decode.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['codebook','method','decode_exact','encoder_decode_exact','test_n','converged_targets','MSE'])
        for key,meta in details.items():
            for met,vals in meta['methods'].items():w.writerow([key,met,vals['decode_exact_ml_or_native'],vals['decode_exact_public_encoder'],vals['test_n'],vals['converged_targets'],vals['mse']])
    print('POSITIVE',positive,flush=True)
    return output
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--train',type=int,default=80);p.add_argument('--test',type=int,default=80);p.add_argument('--MC',type=int,default=128);p.add_argument('--steps',type=int,default=65);p.add_argument('--bootstrap',type=int,default=200);p.add_argument('--skip-imec',action='store_true');args=p.parse_args()
    run(args.train,args.test,args.MC,args.steps,args.bootstrap,args.skip_imec)
