"""R2.7: faithful Algorithm 2 on the public two-dimensional Bernoulli VAE.

Message targets are the same 2-bit codebook for all parameter-space optimizers.
The algorithm computes the KL(P_z || P_target) gradient and a model-sampled
Monte Carlo Fisher estimate at each iteration, with documented damping and
Armijo backtracking. This is NOT a geodesic solver; original S5 path-codebook
is a different mechanism. Upstream iMEC/Discop are handled separately.

This experiment uses fixed synthetic endpoints and is NOT the original MNIST
class-mean S5 benchmark. It is not evidence of general undetectability.
"""
from __future__ import annotations
import json, csv, hashlib, time, argparse
from pathlib import Path
import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score

HERE=Path(__file__).resolve().parent
import sys
sys.path.insert(0,str(HERE.parent))
import benchmark_s5_comparison as b

D=2
EPS=1e-7

def logits_and_jacobian(model,z):
    """Exact piecewise-linear ReLU decoder logits and Jacobian, d=2."""
    W1=model.dec[0].weight.detach().numpy().astype(np.float64)
    bias1=model.dec[0].bias.detach().numpy().astype(np.float64)
    W2=model.dec[2].weight.detach().numpy().astype(np.float64)
    bias2=model.dec[2].bias.detach().numpy().astype(np.float64)
    W3=model.dec[4].weight.detach().numpy().astype(np.float64)
    bias3=model.dec[4].bias.detach().numpy().astype(np.float64)
    a1=W1@z+bias1
    h1=np.maximum(a1,0)
    a2=W2@h1+bias2
    h2=np.maximum(a2,0)
    logits=W3@h2+bias3
    J=W3@((W2*(a2>0)[:,None])@(W1*(a1>0)[:,None]))
    return logits,J

def model_info(model,z,target):
    a,J=logits_and_jacobian(model,z)
    at,_=logits_and_jacobian(model,target)
    p=1/(1+np.exp(-np.clip(a,-50,50)))
    pt=1/(1+np.exp(-np.clip(at,-50,50)))
    # KL Bernoulli(P_z||P_target), computed with stable logits
    kl=float(np.sum(np.logaddexp(0,at)-np.logaddexp(0,a)+p*(a-at)))
    grad=J.T@(p*(1-p)*(a-at))
    F=J.T@((p*(1-p))[:,None]*J)
    return kl,grad,F,p,J

def optimization(model,z0,zt,kind,rng,N=256,max_iter=70,tol=1e-5,damping=1e-3):
    z=z0.copy().astype(float)
    t0=time.perf_counter()
    initial=model_info(model,z,zt)[0]
    loss_hist=[initial]
    sample_count=0
    for it in range(max_iter):
        loss,grad,F,p,J=model_info(model,z,zt)
        if loss < tol:break
        if kind=='Algorithm 2: MC Fisher':
            X=(rng.random((N,p.size))<p[None,:]).astype(np.float64)
            score=(X-p[None,:])@J
            H=score.T@score/N
            sample_count+=N
            direction=np.linalg.solve(H+damping*np.eye(2),grad)
        elif kind=='Natural gradient: exact Fisher':
            direction=np.linalg.solve(F+damping*np.eye(2),grad)
        elif kind=='Euclidean gradient descent':
            direction=grad
        else:raise ValueError(kind)
        if not np.isfinite(direction).all() or grad@direction<=0:break
        alpha=1.0
        for _ in range(28):
            new=z-alpha*direction
            newloss=model_info(model,new,zt)[0]
            if newloss<=loss-1e-4*alpha*(grad@direction):break
            alpha*=.5
        else: break
        z=new
        loss_hist.append(newloss)
    elapsed=time.perf_counter()-t0
    loss=model_info(model,z,zt)[0]
    return dict(z=z.tolist(),iterations=len(loss_hist)-1,initial_kl=initial,terminal_kl=loss,
                converged=bool(loss<=tol),seconds=elapsed,monte_carlo_draws=sample_count,
                final_error=float(np.linalg.norm(z-zt)),monotone=bool(np.all(np.diff(loss_hist)<=1e-8)))

def pub_features(model,imgs,F,z0):
    with torch.no_grad():
        z,_=model.encode(torch.as_tensor(imgs,dtype=torch.float32))
    z=z.numpy();delta=z-z0[None,:]
    return np.column_stack((z,np.einsum('ni,ij,nj->n',delta,F,delta)))

def strat_boot(y,s,seed,B=200):
    auc=roc_auc_score(y,s)
    pos=np.where(y==1)[0];neg=np.where(y==0)[0];rng=np.random.default_rng(seed);v=[]
    for _ in range(B):
        inds=np.r_[rng.choice(pos,len(pos),replace=True),rng.choice(neg,len(neg),replace=True)]
        v.append(roc_auc_score(y[inds],s[inds]))
    return [float(auc),*map(float,np.quantile(v,[.025,.975]))]

def run(n_samples=120,n_test=120,n_fisher=256,max_iter=70,seed=20261031,only=None):
    torch.set_num_threads(1)
    model=b.load_model();z0=np.array([0.,0.]);z1=np.array([1.5,.5]);p0=b.decoder_probs(model,z0)
    codewords=np.linspace(z0,z1,4)
    methods=['Algorithm 2: MC Fisher','Natural gradient: exact Fisher','Euclidean gradient descent']
    evaluation_methods=methods+['iMEC: common Bernoulli channel','Discop: common Bernoulli channel']
    if only is not None: evaluation_methods=[m for m in evaluation_methods if m==only]
    if not evaluation_methods: raise ValueError('unknown --only method')
    out={'protocol':{'seed':seed,'model':'public MNIST VAE checkpoint; synthetic endpoints; 2-bit 4-point codebook for parameter optimizer; Discop uses same p0 and 2-bit message','cover_z':z0.tolist(),'endpoint_z':z1.tolist(),'codewords':codewords.tolist(),'sampler_N':n_fisher,'max_iter':max_iter,'KL_tolerance':1e-5,'damping':1e-3,'train_per_class':n_samples,'test_per_class':n_test,'protocol_warning':'Algorithm 2 objective with model-sampled Fisher and practical damping/Armijo safeguards; NOT original class-mean S5, NOT a geodesic, NOT a security proof'},'optimizers':{},'tests':{},'sha256_checkpoint':hashlib.sha256((b.DATA/'s5_vae_mnist.pt').read_bytes()).hexdigest()}
    for j,kind in enumerate(methods):
        sol=[]
        for m,tgt in enumerate(codewords):
            sol.append(optimization(model,z0,tgt,kind,np.random.default_rng(seed+1000*j+m),N=n_fisher,max_iter=max_iter))
        out['optimizers'][kind]=sol
    F0=b.fisher_metric(model,z0)
    # Common paired message indices across methods and strictly independent splits.
    common_messages = {}
    for split,count,offset in [('train',n_samples,0),('test',n_test,200000)]:
        indices=np.tile(np.arange(4,dtype=int),int(np.ceil(count/4)))[:count]
        common_messages[split]=np.random.default_rng(seed+offset+878).permutation(indices)
    for j,kind in enumerate(evaluation_methods):
        data={}
        for split,count,offset in [('train',n_samples,0),('test',n_test,200000)]:
            covers=np.stack([b.sample_cover(p0,seed+offset+i) for i in range(count)])
            m_idx=common_messages[split] # identical balanced payload assignments across methods
            if kind.startswith('Discop:') or kind.startswith('iMEC:'):
                stego_rows=[];decoded_rows=[]
                for i,m in enumerate(m_idx):
                    msg=b.int_to_bits(int(m),2)
                    img,dec,_,_,_=(b.imec_encode_decode(p0,msg,seed+offset+10000+i,None) if kind.startswith('iMEC:') else b.discop_encode_decode(p0,msg,seed+offset+10000+i))
                    stego_rows.append(img);decoded_rows.append(b.bits_to_int(dec))
                imgs=np.stack(stego_rows)
                decoded=np.array(decoded_rows,dtype=int)
            else:
                imgs=np.stack([b.sample_cover(b.decoder_probs(model,np.asarray(out['optimizers'][kind][int(m)]['z'])),seed+offset+10000+i) for i,m in enumerate(m_idx)])
                with torch.no_grad(): zhat,_=model.encode(torch.as_tensor(imgs,dtype=torch.float32))
                decoded=np.argmin(np.sum((zhat.numpy()[:,None,:]-codewords[None,:,:])**2,axis=2),axis=1)
            data[split]={'cover':covers,'stego':imgs,'target':m_idx,'decoded':decoded}
        train=np.concatenate((data['train']['cover'],data['train']['stego']))
        test=np.concatenate((data['test']['cover'],data['test']['stego']))
        ytrain=np.r_[np.zeros(n_samples,dtype=int),np.ones(n_samples,dtype=int)]
        ytest=np.r_[np.zeros(n_test,dtype=int),np.ones(n_test,dtype=int)]
        metrics={}
        for name,xtrain,xtest in [('pixels',train,test),('public_latent_geometry',pub_features(model,train,F0,z0),pub_features(model,test,F0,z0))]:
            clf=make_pipeline(StandardScaler(),LogisticRegression(C=.5,max_iter=1000,random_state=seed))
            clf.fit(xtrain,ytrain);s=clf.predict_proba(xtest)[:,1]
            metrics[name]=strat_boot(ytest,s,seed+37+j)
        out['tests'][kind]={'detector_AUC_CI95':metrics,'decode_exact':int(np.sum(data['test']['target']==data['test']['decoded'])),'n':n_test,'mse_from_p0':float(np.square(data['test']['stego'].astype(float)-p0).mean()),'optimizer_runs':out['optimizers'].get(kind,None)}
        # Write a checkpoint after EACH method: long baseline runs may be interrupted.
        (HERE/('r27_checkpoint_'+str(j)+'.json')).write_text(json.dumps(out,indent=2))
        print(kind,'AUC',metrics,'decode',out['tests'][kind]['decode_exact'],'converged',sum(z['converged'] for z in out['optimizers'].get(kind,[])),flush=True)
    (HERE/'r27_algorithm2_direct_results.json').write_text(json.dumps(out,indent=2))
    with (HERE/'r27_algorithm2_direct_optimization.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['method','message_index','iterations','initial_KL','terminal_KL','converged','total_seconds','MC_samples','parameter_error'])
        for method,rows in out['optimizers'].items():
            for j,r in enumerate(rows):w.writerow([method,j,r['iterations'],r['initial_kl'],r['terminal_kl'],r['converged'],r['seconds'],r['monte_carlo_draws'],r['final_error']])
    return out
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--samples',type=int,default=120);p.add_argument('--test',type=int,default=120);p.add_argument('--N',type=int,default=256);p.add_argument('--max-iter',type=int,default=70);p.add_argument('--only',type=str,default=None);args=p.parse_args()
    run(args.samples,args.test,args.N,args.max_iter,only=args.only)
